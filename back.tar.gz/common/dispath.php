<?php
/**
* ********************************************
* Description   : 不得姐-路由类
* author        : zhuantou
* Create time   : 2012-02-20
* Last modified : 2012-02-20
* ********************************************
**/

class Dispath{
	function __construct() {
		
	}
	
	
}
 

?>