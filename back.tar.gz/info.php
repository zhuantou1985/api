<?php
include 'common/mysql.php';
include 'include/config.php';
//连接数据库
$mysql = Mysql::getInstance($mysql_config); 


?>
